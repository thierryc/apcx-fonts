# Normale Trial 1.000

Variant: trial
Updated: 2026-05-14
Distribution: paid
Visibility: public-trial

This archive contains the public trial build with a reduced glyph set for evaluation only.

## Folders

- fonts/otf: desktop OpenType fonts
- fonts/ttf: desktop TrueType fonts
- fonts/web: WOFF2 web fonts (WOFF only when no WOFF2 exists)

See MANIFEST.json for machine-readable release metadata and validation results.
