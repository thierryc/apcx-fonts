Normale-stencil-fv Thin Trial 1.000

Variant: trial
Updated: 2026-05-01
Distribution: paid
Visibility: public-trial

This archive contains the public trial build with a reduced glyph set for evaluation only.

Folders:
- fonts/otf: desktop OpenType fonts
- fonts/ttf: desktop TrueType fonts
- fonts/web: WOFF2 web fonts

See MANIFEST.json for machine-readable release metadata.
